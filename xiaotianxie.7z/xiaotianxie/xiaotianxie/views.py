# -*- coding:utf-8 -*-
from django.http import HttpResponse
from django.shortcuts import render,render_to_response
import datetime


def hello(request):
    return HttpResponse("Hello world, My name is xiaotianxie！")

def bye(request):
    return HttpResponse("Byebye,xiaotianxie！")

def currenttime(request):
    now = datetime.datetime.now()
    html = "<html><body>It is now %s.</body></html>" % now
    return HttpResponse(html)

def homepage(request):
    return render_to_response("index.html")

def about(request):
    return render_to_response("about.html")










